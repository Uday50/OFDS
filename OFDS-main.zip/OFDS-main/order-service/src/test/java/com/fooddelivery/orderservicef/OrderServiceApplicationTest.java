package com.fooddelivery.orderservicef;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OrderServiceApplicationTest {

    @Test
    void contextLoads() {
    }
}
