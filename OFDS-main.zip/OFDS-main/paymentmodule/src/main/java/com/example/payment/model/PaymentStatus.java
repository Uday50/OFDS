package com.example.payment.model;

public enum PaymentStatus {
//    SUCCESS,PENDING,FAILED
	Success,Pending,Failed
}
