package com.ofds.menu.contoller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ofds.menu.controller.MenuItemController;
import com.ofds.menu.dto.MenuItemRequestDto;
import com.ofds.menu.dto.MenuItemResponseDto;
import com.ofds.menu.dto.ResponseMessageDto;
import com.ofds.menu.exception.DuplicateMenuItemException;
import com.ofds.menu.exception.InvalidItemIdException;
import com.ofds.menu.exception.InvalidRestaurantIdException;
import com.ofds.menu.exception.MenuItemNotFoundException;
import com.ofds.menu.exception.NoItemsInRestaurantException;
import com.ofds.menu.service.MenuItemService;
import com.ofds.menu.util.AppConstants;

@WebMvcTest(MenuItemController.class)
class MenuItemControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private MenuItemService menuItemService;

	private MenuItemRequestDto menuItemRequestDto;
	private MenuItemResponseDto menuItemResponseDto;
	private ResponseMessageDto successMessageDto;
	private ResponseMessageDto updateMessageDto;

	private final String RESTAURANT_ROLE = "RESTAURANT";
	private final String CUSTOMER_ROLE = "CUSTOMER";
	private final String INTERNAL_USER_ID_HEADER = "X-Internal-User-Id";
	private final String INTERNAL_USER_ROLES_HEADER = "X-Internal-User-Roles";

	@BeforeEach
	void setUp() {
		menuItemRequestDto = new MenuItemRequestDto("Pizza","Delicious cheese pizza",12.99,true);
		menuItemResponseDto = new MenuItemResponseDto(102L,201L,"Pizza","Delicious cheese pizza",12.99,true);
		successMessageDto = new ResponseMessageDto(AppConstants.ITEM_ADDED);
		updateMessageDto = new ResponseMessageDto(AppConstants.ITEM_UPDATED);
	}

	// --- createMenuItem Tests ---
	@Test
	@DisplayName("should return 201 Created when a menu item is successfully created")
	void createMenuItem_Success() throws Exception{
		Long requestId = 1L;
		when(menuItemService.createMenuItem(eq(requestId), any(MenuItemRequestDto.class))).thenReturn(successMessageDto);

		mockMvc.perform(post("/api/menu/restaurant")
				.contentType(MediaType.APPLICATION_JSON)
				.header(INTERNAL_USER_ID_HEADER, String.valueOf(requestId))
				.header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
				.content(objectMapper.writeValueAsString(menuItemRequestDto)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.message").value(AppConstants.ITEM_ADDED));
		verify(menuItemService, times(1)).createMenuItem(eq(requestId), any(MenuItemRequestDto.class));
	}

	@Test
    @DisplayName("should return 403 Forbidden if user role is not RESTAURANT on createMenuItem")
    void createMenuItem_Forbidden() throws Exception {
        Long requestId = 1L;
        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, String.valueOf(requestId))
                .header(INTERNAL_USER_ROLES_HEADER, CUSTOMER_ROLE)
                .content(objectMapper.writeValueAsString(menuItemRequestDto)))
                .andExpect(status().isForbidden());
        verifyNoInteractions(menuItemService);
    }

	@Test
	@DisplayName("should return 400 Bad Request for invalid restaurant ID in createMenuItem")
	void createMenuItem_InvalidRestaurantId() throws Exception{
		Long invalidRequestId = 0L;
		when(menuItemService.createMenuItem(eq(invalidRequestId),any(MenuItemRequestDto.class)))
		    .thenThrow(new InvalidRestaurantIdException(AppConstants.INVALID_RESTAURANTID + invalidRequestId));

		mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, String.valueOf(invalidRequestId))
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(menuItemRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(AppConstants.INVALID_RESTAURANTID + invalidRequestId));
        verify(menuItemService, times(1)).createMenuItem(eq(invalidRequestId), any(MenuItemRequestDto.class));
	}


	@Test
    @DisplayName("should return 409 Conflict for duplicate menu item creation")
    void createMenuItem_DuplicateItem() throws Exception {
        Long requestId = 1L;
        String duplicateItemName = "Pizza";
        when(menuItemService.createMenuItem(eq(requestId), any(MenuItemRequestDto.class)))
                .thenThrow(new DuplicateMenuItemException(AppConstants.DUPLICATE_ITEM + duplicateItemName));

        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, String.valueOf(requestId))
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(menuItemRequestDto)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.message").value(AppConstants.DUPLICATE_ITEM + duplicateItemName));
        verify(menuItemService, times(1)).createMenuItem(eq(requestId), any(MenuItemRequestDto.class));
    }

	@Test
    @DisplayName("should return 400 Bad Request for missing itemName in createMenuItem payload due to @Valid")
    void createMenuItem_Validation_MissingItemName() throws Exception {
        MenuItemRequestDto invalidRequestDto = new MenuItemRequestDto(
            null, "A valid description for pizza", 12.99, true
        );
        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, "1")
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(invalidRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.itemName").value("Item name cannot be empty"));
        verifyNoInteractions(menuItemService);
    }

	@Test
    @DisplayName("should return 400 Bad Request for short itemName in createMenuItem payload due to @Valid")
    void createMenuItem_Validation_ShortItemName() throws Exception {
        MenuItemRequestDto invalidRequestDto = new MenuItemRequestDto(
            "Piz", "A valid description for pizza", 12.99, true
        );
        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, "1")
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(invalidRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.itemName").value("Item name must be between 5 and 50 characters"));
        verifyNoInteractions(menuItemService);
    }

	@Test
    @DisplayName("should return 400 Bad Request for null price in createMenuItem payload due to @Valid")
    void createMenuItem_Validation_NullPrice() throws Exception {
        MenuItemRequestDto invalidRequestDto = new MenuItemRequestDto(
            "Delicious Pizza", "A valid description for pizza", null, true
        );
        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, "1")
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(invalidRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.price").value("Price cannot be null"));
        verifyNoInteractions(menuItemService);
    }

    @Test
    @DisplayName("should return 400 Bad Request for price less than 0.01 in createMenuItem payload due to @Valid")
    void createMenuItem_Validation_MinPrice() throws Exception {
        MenuItemRequestDto invalidRequestDto = new MenuItemRequestDto(
            "Delicious Pizza", "A valid description for pizza", 0.00, true
        );
        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, "1")
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(invalidRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.price").value("Price must be greater than 0"));
        verifyNoInteractions(menuItemService);
    }

    @Test
    @DisplayName("should return 400 Bad Request for multiple validation errors in createMenuItem payload")
    void createMenuItem_Validation_MultipleErrors() throws Exception {
        MenuItemRequestDto invalidRequestDto = new MenuItemRequestDto("Piz",null,-10.0,null);

        mockMvc.perform(post("/api/menu/restaurant")
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ID_HEADER, "1")
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(invalidRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.itemName").exists())
                .andExpect(jsonPath("$.description").exists())
                .andExpect(jsonPath("$.price").exists())
                .andExpect(jsonPath("$.isVegetarian").exists());
        verifyNoInteractions(menuItemService);
    }

	// --- updateMenuItem Tests ---
    @Test
    @DisplayName("should return 200 OK when a menu item is successfully updated")
    void updateMenuItem_Success() throws Exception {
        Long itemId = 101L;
        when(menuItemService.updateMenuItem(eq(itemId), any(MenuItemRequestDto.class)))
                .thenReturn(updateMessageDto);

        mockMvc.perform(put("/api/menu/{itemId}", itemId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(menuItemRequestDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value(AppConstants.ITEM_UPDATED));
        verify(menuItemService, times(1)).updateMenuItem(eq(itemId), any(MenuItemRequestDto.class));
    }

    @Test
    @DisplayName("should return 403 Forbidden if user role is not RESTAURANT on updateMenuItem")
    void updateMenuItem_Forbidden() throws Exception {
        Long itemId = 101L;
        mockMvc.perform(put("/api/menu/{itemId}", itemId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ROLES_HEADER, CUSTOMER_ROLE) // Customer role
                .content(objectMapper.writeValueAsString(menuItemRequestDto)))
                .andExpect(status().isForbidden());
        verifyNoInteractions(menuItemService);
    }

    @Test
    @DisplayName("should return 404 Not Found when updating a non-existent menu item")
    void updateMenuItem_NotFound() throws Exception {
        Long itemId = 999L;
        when(menuItemService.updateMenuItem(eq(itemId), any(MenuItemRequestDto.class)))
                .thenThrow(new MenuItemNotFoundException(AppConstants.ITEM_NOTFOUND + itemId));

        mockMvc.perform(put("/api/menu/{itemId}", itemId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(menuItemRequestDto)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(HttpStatus.NOT_FOUND.value()))
                .andExpect(jsonPath("$.message").value(AppConstants.ITEM_NOTFOUND + itemId));
        verify(menuItemService, times(1)).updateMenuItem(eq(itemId), any(MenuItemRequestDto.class));
    }

    @Test
    @DisplayName("should return 400 Bad Request for invalid request body (validation failure) on update")
    void updateMenuItem_Validation_NullDescription() throws Exception {
        Long itemId = 101L;
        MenuItemRequestDto invalidRequestDto = new MenuItemRequestDto("ValidName", null, 10.0, true);

        mockMvc.perform(put("/api/menu/{itemId}", itemId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE)
                .content(objectMapper.writeValueAsString(invalidRequestDto)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.description").value("Description cannot be empty or null"));
        verifyNoInteractions(menuItemService);
    }

    @Test
    @DisplayName("should return 403 Forbidden if user role is not RESTAURANT on deleteMenuItem")
    void deleteMenuItem_Forbidden() throws Exception {
        Long itemId = 101L;
        mockMvc.perform(delete("/api/menu/{itemId}", itemId)
                .header(INTERNAL_USER_ROLES_HEADER, CUSTOMER_ROLE))
                .andExpect(status().isForbidden());
        verifyNoInteractions(menuItemService);
    }

    @Test
    @DisplayName("should return 404 Not Found when deleting a non-existent menu item")
    void deleteMenuItem_NotFound() throws Exception {
        Long itemId = 999L;
        doThrow(new MenuItemNotFoundException(AppConstants.ITEM_NOTFOUND + itemId))
                .when(menuItemService).deleteMenuItem(itemId);

        mockMvc.perform(delete("/api/menu/{itemId}", itemId)
                .header(INTERNAL_USER_ROLES_HEADER, RESTAURANT_ROLE))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(HttpStatus.NOT_FOUND.value()))
                .andExpect(jsonPath("$.message").value(AppConstants.ITEM_NOTFOUND + itemId));
        verify(menuItemService, times(1)).deleteMenuItem(itemId);
    }

	// --- getMenuItemById Tests ---
    @Test
    @DisplayName("should return 200 OK when retrieving a menu item by ID")
    void getMenuItemById_Success() throws Exception {
        Long itemId = 101L;
        when(menuItemService.getMenuItemById(itemId)).thenReturn(menuItemResponseDto);

        mockMvc.perform(get("/api/menu/{itemId}", itemId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.itemName").value(menuItemResponseDto.getItemName()))
                .andExpect(jsonPath("$.price").value(menuItemResponseDto.getPrice()));
        verify(menuItemService, times(1)).getMenuItemById(itemId);
    }

    @Test
    @DisplayName("should return 404 Not Found when retrieving a non-existent menu item by ID")
    void getMenuItemById_NotFound() throws Exception {
        Long itemId = 999L;
        when(menuItemService.getMenuItemById(itemId))
                .thenThrow(new MenuItemNotFoundException(AppConstants.ITEM_NOTFOUND + itemId));

        mockMvc.perform(get("/api/menu/{itemId}", itemId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(HttpStatus.NOT_FOUND.value()))
                .andExpect(jsonPath("$.message").value(AppConstants.ITEM_NOTFOUND + itemId));
        verify(menuItemService, times(1)).getMenuItemById(itemId);
    }

    @Test
    @DisplayName("should return 400 Bad Request for invalid item ID (e.g., zero/negative) in getMenuItemById")
    void getMenuItemById_InvalidItemId() throws Exception {
        Long invalidItemId = 0L;
        when(menuItemService.getMenuItemById(invalidItemId))
                .thenThrow(new InvalidItemIdException(AppConstants.INVALID_ITEMID + invalidItemId));

        mockMvc.perform(get("/api/menu/{itemId}", invalidItemId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(HttpStatus.BAD_REQUEST.value()))
                .andExpect(jsonPath("$.message").value(AppConstants.INVALID_ITEMID + invalidItemId));
        verify(menuItemService, times(1)).getMenuItemById(invalidItemId);
    }

	// --- getMenuItemsByResturant Tests (by PathVariable restaurantId) ---
    @Test
    @DisplayName("should return 200 OK with a list of menu items for a restaurant by path variable")
    void getMenuItemsByResturant_Success() throws Exception {
        Long restaurantId = 1L;
        List<MenuItemResponseDto> menuItems = Arrays.asList(menuItemResponseDto, new MenuItemResponseDto(110L,203L,"Classic Burger", "Classic beef burger with all the fixings", 8.50,false));
        when(menuItemService.getAllMenuItemsByResturant(restaurantId)).thenReturn(menuItems);

        mockMvc.perform(get("/api/menu/restaurant/{restaurantId}", restaurantId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].itemName").value(menuItemResponseDto.getItemName()))
                .andExpect(jsonPath("$[1].itemName").value("Classic Burger"));
        verify(menuItemService, times(1)).getAllMenuItemsByResturant(restaurantId);
    }

    @Test
    @DisplayName("should return 404 Not Found if no menu items are found for a restaurant by path variable")
    void getMenuItemsByResturant_NoItemsFound() throws Exception {
        Long restaurantId = 1L;
        when(menuItemService.getAllMenuItemsByResturant(restaurantId))
                .thenThrow(new NoItemsInRestaurantException(AppConstants.NOITEMS_IN_RESTAURANT + restaurantId));

        mockMvc.perform(get("/api/menu/restaurant/{restaurantId}", restaurantId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(HttpStatus.NOT_FOUND.value()))
                .andExpect(jsonPath("$.message").value(AppConstants.NOITEMS_IN_RESTAURANT + restaurantId));
        verify(menuItemService, times(1)).getAllMenuItemsByResturant(restaurantId);
    }

    @Test
    @DisplayName("should return 400 Bad Request for invalid restaurant ID on getMenuItemsByRestaurant by path variable")
    void getMenuItemsByResturant_InvalidRestaurantId() throws Exception {
        Long invalidRestaurantId = 0L;
        when(menuItemService.getAllMenuItemsByResturant(invalidRestaurantId))
                .thenThrow(new InvalidRestaurantIdException(AppConstants.INVALID_RESTAURANTID + invalidRestaurantId));

        mockMvc.perform(get("/api/menu/restaurant/{restaurantId}", invalidRestaurantId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(HttpStatus.BAD_REQUEST.value()))
                .andExpect(jsonPath("$.message").value(AppConstants.INVALID_RESTAURANTID + invalidRestaurantId));
        verify(menuItemService, times(1)).getAllMenuItemsByResturant(invalidRestaurantId);
    }
}