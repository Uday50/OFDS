/*INSERT INTO menu_item (
    item_id, restaurant_id, item_name, description, price, image_url, is_available, created_at, created_by, updated_at, updated_by
) VALUES 
(1, 101, 'Margherita Pizza', 'Classic pizza with tomatoes, mozzarella, and basil.', 299.99, 'https://example.com/images/pizza1.jpg', TRUE, CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'admin'),
(2, 101, 'Veg Burger', 'A delicious vegetable patty burger with cheese.', 149.50, 'https://example.com/images/burger1.jpg', TRUE, CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'admin'),
(3, 102, 'Chicken Biryani', 'Spicy chicken biryani with fragrant basmati rice.', 399.00, 'https://example.com/images/biryani1.jpg', TRUE, CURRENT_TIMESTAMP, 'chef_mohit', CURRENT_TIMESTAMP, 'chef_mohit'),
(4, 103, 'Paneer Tikka', 'Grilled paneer cubes marinated in spices.', 249.75, 'https://example.com/images/paneer1.jpg', TRUE, CURRENT_TIMESTAMP, 'admin', CURRENT_TIMESTAMP, 'admin'),
(5, 104, 'Cold Coffee', 'Chilled coffee with ice cream and chocolate.', 120.00, 'https://example.com/images/coffee1.jpg', TRUE, CURRENT_TIMESTAMP, 'staff1', CURRENT_TIMESTAMP, 'staff1');
 */